/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "ab2e450022130fef21e3cf647b0a0247"
  }, {
    "url": "pwa-512x512.png",
    "revision": "6f634ee0ea0036d4e9b467abfe1eaeef"
  }, {
    "url": "pwa-192x192.png",
    "revision": "4d2331b954503346a5e9224d01b07c40"
  }, {
    "url": "index.html",
    "revision": "69db91eba9f44289e06e0f50ba12b451"
  }, {
    "url": "icon.svg",
    "revision": "4c16411596b6e3329c00dd04090ee908"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "27ecd0f71c784ebd73afa2e0e151d3ed"
  }, {
    "url": "assets/index-DNXLbL6l.css",
    "revision": null
  }, {
    "url": "assets/index-5P7EZIz9.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "27ecd0f71c784ebd73afa2e0e151d3ed"
  }, {
    "url": "icon.svg",
    "revision": "4c16411596b6e3329c00dd04090ee908"
  }, {
    "url": "pwa-192x192.png",
    "revision": "4d2331b954503346a5e9224d01b07c40"
  }, {
    "url": "pwa-512x512.png",
    "revision": "6f634ee0ea0036d4e9b467abfe1eaeef"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "ab2e450022130fef21e3cf647b0a0247"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e5dc37bef77ffdb343e915125a167e92"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
